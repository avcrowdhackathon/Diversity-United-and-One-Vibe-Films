(function($){
	'use strict';

	$('.toplevel_page_acf-options .acf-postbox > h2').after('<h3 class="theme_option_subnav"><a href="https://wpml.org/?aid=63524&affiliate_key=wP53KkuDHd0l" target="_blank">Buy WPML</a><a href="https://yosupport.freshdesk.com/" target="_blank">Theme Support</a></h3>')

})(jQuery);