# Changelog

#### 0.6.4
* Improve markup of preview iframe

#### 0.6.3
* Bug fix: load font-family(move preview to an iframe)
* Clean Codes & 50 jshint.com warning fixed

#### 0.6.2
* Bug fix: default font-weight return 'regular'
* Remove letter-spacing from required check

#### 0.6.0
* Add required check

#### 0.5.0
* Compatible with [Github Updater](https://github.com/afragen/github-updater)
* add language pot file
* add changelog file
* add required check

#### 0.4.0
* Add letter spacing
* bug fix: Font Style
* bug fix: API KEY
* Some bug fixes

#### 0.3.1
* Some bug fixes

#### 0.3.0
*Add: Color Picker

#### 0.2.0
* Add: Style for display fields 

#### 0.1.2
* bug fix : When Load more than one typography field in a page
* bug fix : Font Size label show display
* bug fix : 400 to place regular in Font Weight
* bug fix : Change font style label
* bug fix : Add font style field

#### 0.1.1
* Some bug fixes
* Clean Files & Codes.

#### 0.1.0
* Initial Release.