<?php
if(function_exists('vc_map')) {

vc_remove_param('vc_vc_toggle', 'color');
vc_remove_param('vc_vc_toggle', 'style');


}